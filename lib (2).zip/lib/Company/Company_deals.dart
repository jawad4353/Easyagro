

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Company_deals extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    var size=MediaQuery.of(context).size;
   return Scaffold(
     appBar: AppBar(backgroundColor: Colors.green.shade700,),
   );
  }
  
}