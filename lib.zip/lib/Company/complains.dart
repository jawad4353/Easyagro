



import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


class Company_complaints extends StatefulWidget {
  @override
  State<Company_complaints> createState() => _Company_complaintsState();
}

class _Company_complaintsState extends State<Company_complaints> {
  @override
  Widget build(BuildContext context) {
 return Scaffold(
   backgroundColor: Colors.white,
   appBar: AppBar(title: Text('Compaints'),),
   body:ListView(
     children: [

   ],
   ) ,
 );
  }
}
